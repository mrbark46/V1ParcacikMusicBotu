// Main App component — multi-room music chat platform
import { useState, useCallback } from "react";
import { NicknameModal } from "@/components/NicknameModal";
import { RoomSidebar } from "@/components/RoomSidebar";
import { ChatArea } from "@/components/ChatArea";
import { MusicPlayer } from "@/components/MusicPlayer";
import { useSocket } from "@/hooks/useSocket";
import type {
  ChatMessage,
  PlaybackState,
  QueueItem,
  RoomListItem,
  RoomState,
  RoomUser,
} from "@/types";

export default function App() {
  const [nickname, setNickname] = useState<string | null>(null);
  const [roomList, setRoomList] = useState<RoomListItem[]>([]);
  const [currentRoomId, setCurrentRoomId] = useState<string | null>(null);
  const [currentRoomName, setCurrentRoomName] = useState<string | null>(null);
  const [users, setUsers] = useState<RoomUser[]>([]);
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [playback, setPlayback] = useState<PlaybackState | null>(null);
  const [queue, setQueue] = useState<QueueItem[]>([]);
  const [mobileView, setMobileView] = useState<"chat" | "player" | "sidebar">("chat");

  const handleRoomJoined = useCallback((room: RoomState) => {
    setCurrentRoomId(room.id);
    setCurrentRoomName(room.name);
    setUsers(room.users);
    setMessages(room.chatHistory);
    setPlayback(room.playback);
    setQueue(room.playback.queue);
  }, []);

  const handlePlaybackUpdate = useCallback((state: PlaybackState) => {
    setPlayback(state);
    setQueue(state.queue);
  }, []);

  const {
    joinRoom,
    sendMessage,
    addToQueue,
    skipSong,
    pausePlayback,
    resumePlayback,
    removeFromQueue,
    reorderQueue,
    clearQueue,
    songEnded,
  } = useSocket({
    onRoomList: setRoomList,
    onRoomJoined: handleRoomJoined,
    onUserList: setUsers,
    onChatMessage: (msg) => setMessages((prev) => [...prev, msg]),
    onPlaybackUpdate: handlePlaybackUpdate,
    onQueueUpdate: setQueue,
  });

  const handleJoinRoom = useCallback(
    (roomId: string, roomName: string) => {
      if (!nickname) return;
      joinRoom(roomId, roomName, nickname);
      setMobileView("chat");
    },
    [nickname, joinRoom]
  );

  // Show nickname modal until user enters name
  if (!nickname) {
    return <NicknameModal onSet={setNickname} />;
  }

  const inRoom = !!currentRoomId;

  return (
    <div className="flex h-screen bg-gray-950 text-white overflow-hidden">
      {/* Left Sidebar */}
      <div className={`${mobileView === "sidebar" ? "flex" : "hidden"} md:flex flex-col h-full shrink-0`}>
        <RoomSidebar
          rooms={roomList}
          currentRoomId={currentRoomId}
          currentRoomName={currentRoomName}
          users={users}
          nickname={nickname}
          onJoinRoom={handleJoinRoom}
        />
      </div>

      {/* Main Area */}
      <div className={`${mobileView === "chat" ? "flex" : "hidden"} md:flex flex-col flex-1 min-w-0 h-full`}>
        {/* Room Header */}
        <div className="flex items-center justify-between px-4 py-3 border-b border-gray-800 bg-gray-900 shrink-0">
          <div className="flex items-center gap-2">
            {/* Mobile: show sidebar toggle */}
            <button
              className="md:hidden text-gray-400 hover:text-white mr-1"
              onClick={() => setMobileView("sidebar")}
            >
              ☰
            </button>
            {currentRoomName ? (
              <>
                <span className="text-violet-400 text-sm font-semibold">#</span>
                <h2 className="text-white font-semibold">{currentRoomName}</h2>
                <span className="text-gray-500 text-xs">({currentRoomId})</span>
              </>
            ) : (
              <h2 className="text-gray-500 text-sm">Bir odaya katılın</h2>
            )}
          </div>
          <div className="flex items-center gap-2">
            {/* Mobile: show player toggle */}
            <button
              className="md:hidden text-gray-400 hover:text-white text-xs bg-gray-800 px-2 py-1 rounded-lg"
              onClick={() => setMobileView("player")}
            >
              ♪ Müzik
            </button>
            <span className="hidden md:inline text-gray-500 text-xs">{users.length} kullanıcı</span>
          </div>
        </div>

        {/* Chat */}
        <div className="flex-1 min-h-0">
          <ChatArea
            messages={messages}
            nickname={nickname}
            onSend={sendMessage}
            disabled={!inRoom}
          />
        </div>
      </div>

      {/* Right Panel — Music Player & Queue */}
      <div
        className={`${mobileView === "player" ? "flex" : "hidden"} md:flex flex-col h-full w-80 min-w-[280px] max-w-[320px] border-l border-gray-800 bg-gray-950 shrink-0`}
      >
        {/* Mobile back button */}
        <div className="flex md:hidden items-center px-3 py-2 border-b border-gray-800">
          <button
            onClick={() => setMobileView("chat")}
            className="text-gray-400 hover:text-white text-sm"
          >
            ← Sohbete Dön
          </button>
        </div>
        <MusicPlayer
          playback={playback}
          queue={queue}
          onSkip={skipSong}
          onPause={pausePlayback}
          onResume={resumePlayback}
          onClearQueue={clearQueue}
          onRemoveFromQueue={removeFromQueue}
          onReorderQueue={reorderQueue}
          onSongEnded={songEnded}
          onAddToQueue={addToQueue}
          disabled={!inRoom}
        />
      </div>
    </div>
  );
}
