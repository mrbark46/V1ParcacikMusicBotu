// Nickname entry modal shown on first load
import { useState } from "react";

interface NicknameModalProps {
  onSet: (nickname: string) => void;
}

export function NicknameModal({ onSet }: NicknameModalProps) {
  const [value, setValue] = useState("");

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const trimmed = value.trim();
    if (trimmed.length < 2) return;
    onSet(trimmed);
  };

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/80 backdrop-blur-sm">
      <div className="w-full max-w-sm mx-4 bg-gray-900 border border-gray-700 rounded-2xl p-8 shadow-2xl">
        <div className="text-center mb-6">
          <div className="text-4xl mb-3">🎵</div>
          <h1 className="text-2xl font-bold text-white">Müzik Chat</h1>
          <p className="text-gray-400 text-sm mt-2">Arkadaşlarınla müzik dinle</p>
        </div>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <input
              type="text"
              value={value}
              onChange={(e) => setValue(e.target.value)}
              placeholder="İsminizi girin..."
              className="w-full bg-gray-800 border border-gray-600 text-white rounded-xl px-4 py-3 placeholder-gray-500 focus:outline-none focus:border-violet-500 focus:ring-1 focus:ring-violet-500 transition"
              maxLength={24}
              autoFocus
            />
          </div>
          <button
            type="submit"
            disabled={value.trim().length < 2}
            className="w-full bg-violet-600 hover:bg-violet-500 disabled:opacity-40 disabled:cursor-not-allowed text-white font-semibold rounded-xl py-3 transition"
          >
            Giriş Yap
          </button>
        </form>
      </div>
    </div>
  );
}
