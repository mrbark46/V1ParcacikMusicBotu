// Left sidebar: room list, create/join room, and user list
import { useState } from "react";
import type { RoomListItem, RoomUser } from "@/types";

interface RoomSidebarProps {
  rooms: RoomListItem[];
  currentRoomId: string | null;
  currentRoomName: string | null;
  users: RoomUser[];
  nickname: string;
  onJoinRoom: (roomId: string, roomName: string) => void;
}

function generateRoomId(): string {
  return Math.random().toString(36).substring(2, 8).toUpperCase();
}

export function RoomSidebar({
  rooms,
  currentRoomId,
  currentRoomName,
  users,
  nickname,
  onJoinRoom,
}: RoomSidebarProps) {
  const [showCreate, setShowCreate] = useState(false);
  const [showJoin, setShowJoin] = useState(false);
  const [newRoomName, setNewRoomName] = useState("");
  const [joinCode, setJoinCode] = useState("");

  const handleCreate = (e: React.FormEvent) => {
    e.preventDefault();
    const name = newRoomName.trim();
    if (!name) return;
    const id = generateRoomId();
    onJoinRoom(id, name);
    setNewRoomName("");
    setShowCreate(false);
  };

  const handleJoin = (e: React.FormEvent) => {
    e.preventDefault();
    const code = joinCode.trim().toUpperCase();
    if (!code) return;
    // Find room by ID or create with that ID
    const existing = rooms.find((r) => r.id === code);
    onJoinRoom(code, existing?.name ?? code);
    setJoinCode("");
    setShowJoin(false);
  };

  return (
    <aside className="flex flex-col h-full w-64 min-w-[220px] max-w-[280px] bg-gray-900 border-r border-gray-800">
      {/* Header */}
      <div className="p-4 border-b border-gray-800">
        <div className="flex items-center gap-2 mb-1">
          <span className="text-violet-400 text-xl">🎵</span>
          <h1 className="text-white font-bold text-lg">Müzik Chat</h1>
        </div>
        <p className="text-gray-500 text-xs truncate">
          <span className="text-violet-400">●</span> {nickname}
        </p>
      </div>

      {/* Room Actions */}
      <div className="p-3 border-b border-gray-800 space-y-2">
        <button
          onClick={() => { setShowCreate(true); setShowJoin(false); }}
          className="w-full bg-violet-600 hover:bg-violet-500 text-white text-sm font-semibold rounded-lg px-3 py-2 transition"
        >
          Oda Oluştur
        </button>
        <button
          onClick={() => { setShowJoin(true); setShowCreate(false); }}
          className="w-full bg-gray-700 hover:bg-gray-600 text-white text-sm font-semibold rounded-lg px-3 py-2 transition"
        >
          Odaya Katıl
        </button>

        {showCreate && (
          <form onSubmit={handleCreate} className="mt-2 space-y-2">
            <input
              type="text"
              value={newRoomName}
              onChange={(e) => setNewRoomName(e.target.value)}
              placeholder="Oda adı..."
              className="w-full bg-gray-800 border border-gray-600 text-white text-sm rounded-lg px-3 py-2 placeholder-gray-500 focus:outline-none focus:border-violet-500"
              maxLength={32}
              autoFocus
            />
            <div className="flex gap-2">
              <button type="submit" className="flex-1 bg-violet-600 hover:bg-violet-500 text-white text-sm rounded-lg py-1.5 transition">Oluştur</button>
              <button type="button" onClick={() => setShowCreate(false)} className="flex-1 bg-gray-700 hover:bg-gray-600 text-white text-sm rounded-lg py-1.5 transition">İptal</button>
            </div>
          </form>
        )}

        {showJoin && (
          <form onSubmit={handleJoin} className="mt-2 space-y-2">
            <input
              type="text"
              value={joinCode}
              onChange={(e) => setJoinCode(e.target.value)}
              placeholder="Oda kodu..."
              className="w-full bg-gray-800 border border-gray-600 text-white text-sm rounded-lg px-3 py-2 placeholder-gray-500 focus:outline-none focus:border-violet-500"
              maxLength={8}
              autoFocus
            />
            <div className="flex gap-2">
              <button type="submit" className="flex-1 bg-violet-600 hover:bg-violet-500 text-white text-sm rounded-lg py-1.5 transition">Katıl</button>
              <button type="button" onClick={() => setShowJoin(false)} className="flex-1 bg-gray-700 hover:bg-gray-600 text-white text-sm rounded-lg py-1.5 transition">İptal</button>
            </div>
          </form>
        )}
      </div>

      {/* Room List */}
      <div className="flex-1 overflow-y-auto">
        <div className="px-3 py-2">
          <p className="text-gray-500 text-xs font-semibold uppercase tracking-wider mb-2">Odalar</p>
          {rooms.length === 0 && (
            <p className="text-gray-600 text-xs text-center py-4">Henüz oda yok</p>
          )}
          {rooms.map((room) => (
            <button
              key={room.id}
              onClick={() => onJoinRoom(room.id, room.name)}
              className={`w-full text-left rounded-lg px-3 py-2 mb-1 transition group ${
                currentRoomId === room.id
                  ? "bg-violet-600/30 border border-violet-600/50"
                  : "hover:bg-gray-800 border border-transparent"
              }`}
            >
              <div className="flex items-center justify-between">
                <span className={`text-sm font-medium truncate ${currentRoomId === room.id ? "text-violet-300" : "text-gray-300"}`}>
                  {room.hasMusic ? "♪ " : ""}{room.name}
                </span>
                <span className="text-xs text-gray-500 ml-1 shrink-0">{room.userCount}</span>
              </div>
              <p className="text-xs text-gray-500">{room.id}</p>
            </button>
          ))}
        </div>
      </div>

      {/* User List in Current Room */}
      {currentRoomId && (
        <div className="border-t border-gray-800 p-3 max-h-48 overflow-y-auto">
          <p className="text-gray-500 text-xs font-semibold uppercase tracking-wider mb-2">
            {currentRoomName} — Kullanıcılar ({users.length})
          </p>
          {users.map((user) => (
            <div key={user.socketId} className="flex items-center gap-2 py-1">
              <span className="w-2 h-2 rounded-full bg-green-500 shrink-0"></span>
              <span className={`text-sm truncate ${user.nickname === nickname ? "text-violet-300 font-medium" : "text-gray-400"}`}>
                {user.nickname}{user.nickname === nickname ? " (sen)" : ""}
              </span>
            </div>
          ))}
        </div>
      )}
    </aside>
  );
}
