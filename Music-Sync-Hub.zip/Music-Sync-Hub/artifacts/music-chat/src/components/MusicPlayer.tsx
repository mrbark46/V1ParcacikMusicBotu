// YouTube music player with sync logic
import { useEffect, useRef, useCallback, useState } from "react";
import type { PlaybackState, QueueItem } from "@/types";

declare global {
  interface Window {
    YT: {
      Player: new (element: string | HTMLElement, options: object) => YTPlayer;
      PlayerState: {
        ENDED: number;
        PLAYING: number;
        PAUSED: number;
        BUFFERING: number;
        CUED: number;
      };
    };
    onYouTubeIframeAPIReady: () => void;
  }
}

interface YTPlayer {
  seekTo: (seconds: number, allowSeekAhead: boolean) => void;
  playVideo: () => void;
  pauseVideo: () => void;
  stopVideo: () => void;
  loadVideoById: (videoId: string, startSeconds?: number) => void;
  cueVideoById: (videoId: string) => void;
  getCurrentTime: () => number;
  getDuration: () => number;
  getPlayerState: () => number;
  destroy: () => void;
}

interface MusicPlayerProps {
  playback: PlaybackState | null;
  queue: QueueItem[];
  onSkip: () => void;
  onPause: () => void;
  onResume: () => void;
  onClearQueue: () => void;
  onRemoveFromQueue: (id: string) => void;
  onReorderQueue: (from: number, to: number) => void;
  onSongEnded: () => void;
  onAddToQueue: (url: string, title: string) => void;
  disabled?: boolean;
}

let apiLoaded = false;
let apiCallbacks: (() => void)[] = [];

function loadYouTubeAPI(callback: () => void) {
  if (apiLoaded) {
    callback();
    return;
  }
  apiCallbacks.push(callback);
  if (document.getElementById("yt-api")) return;
  const tag = document.createElement("script");
  tag.id = "yt-api";
  tag.src = "https://www.youtube.com/iframe_api";
  document.head.appendChild(tag);
  window.onYouTubeIframeAPIReady = () => {
    apiLoaded = true;
    apiCallbacks.forEach((cb) => cb());
    apiCallbacks = [];
  };
}

function formatDuration(seconds: number): string {
  const m = Math.floor(seconds / 60);
  const s = Math.floor(seconds % 60);
  return `${m}:${s.toString().padStart(2, "0")}`;
}

export function MusicPlayer({
  playback,
  queue,
  onSkip,
  onPause,
  onResume,
  onClearQueue,
  onRemoveFromQueue,
  onReorderQueue,
  onSongEnded,
  onAddToQueue,
  disabled,
}: MusicPlayerProps) {
  const playerRef = useRef<YTPlayer | null>(null);
  const containerRef = useRef<HTMLDivElement>(null);
  const lastVideoId = useRef<string | null>(null);
  const [addUrl, setAddUrl] = useState("");
  const [dragIndex, setDragIndex] = useState<number | null>(null);

  const handlePlayerReady = useCallback(() => {
    // Sync on player ready
    if (playback?.currentVideoId) {
      const elapsed = playback.elapsedSeconds;
      playerRef.current?.loadVideoById(playback.currentVideoId, elapsed);
      if (!playback.isPlaying) {
        setTimeout(() => playerRef.current?.pauseVideo(), 500);
      }
    }
  }, [playback]);

  // Initialize YouTube player
  useEffect(() => {
    loadYouTubeAPI(() => {
      if (!containerRef.current) return;
      playerRef.current = new window.YT.Player(containerRef.current, {
        height: "100%",
        width: "100%",
        playerVars: {
          autoplay: 1,
          controls: 0,
          disablekb: 1,
          fs: 0,
          modestbranding: 1,
          rel: 0,
        },
        events: {
          onReady: handlePlayerReady,
          onStateChange: (event: { data: number }) => {
            if (event.data === window.YT.PlayerState.ENDED) {
              onSongEnded();
            }
          },
        },
      });
    });

    return () => {
      playerRef.current?.destroy();
      playerRef.current = null;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  // Sync player with playback state changes
  useEffect(() => {
    if (!playerRef.current || !playback) return;

    const { currentVideoId, isPlaying, elapsedSeconds } = playback;

    if (currentVideoId !== lastVideoId.current) {
      // New video
      lastVideoId.current = currentVideoId;
      if (currentVideoId) {
        playerRef.current.loadVideoById(currentVideoId, elapsedSeconds);
        if (!isPlaying) {
          setTimeout(() => playerRef.current?.pauseVideo(), 800);
        }
      } else {
        playerRef.current.stopVideo();
      }
      return;
    }

    // Same video — sync time if drifted
    if (currentVideoId) {
      const currentTime = playerRef.current.getCurrentTime();
      const drift = Math.abs(currentTime - elapsedSeconds);
      if (drift > 3) {
        playerRef.current.seekTo(elapsedSeconds, true);
      }
      if (isPlaying) {
        playerRef.current.playVideo();
      } else {
        playerRef.current.pauseVideo();
      }
    }
  }, [playback]);

  const handleAddUrl = (e: React.FormEvent) => {
    e.preventDefault();
    const url = addUrl.trim();
    if (!url) return;
    onAddToQueue(url, "");
    setAddUrl("");
  };

  // Drag-and-drop for queue reordering
  const handleDragStart = (index: number) => setDragIndex(index);
  const handleDragOver = (e: React.DragEvent, index: number) => {
    e.preventDefault();
    if (dragIndex !== null && dragIndex !== index) {
      onReorderQueue(dragIndex, index);
      setDragIndex(index);
    }
  };
  const handleDragEnd = () => setDragIndex(null);

  const hasVideo = !!playback?.currentVideoId;

  return (
    <div className="flex flex-col h-full">
      {/* Video Player */}
      <div className="relative bg-black" style={{ paddingTop: "56.25%", minHeight: 0 }}>
        <div
          className="absolute inset-0"
          style={{ display: hasVideo ? "block" : "none" }}
        >
          <div ref={containerRef} className="w-full h-full" />
        </div>
        {!hasVideo && (
          <div className="absolute inset-0 flex flex-col items-center justify-center bg-gray-900">
            <div className="text-5xl mb-3 opacity-30">♪</div>
            <p className="text-gray-500 text-sm">Sıra boş — bir şarkı ekle</p>
          </div>
        )}
      </div>

      {/* Playback Controls */}
      <div className="px-4 py-3 bg-gray-900 border-b border-gray-800">
        {playback?.currentVideoId && (
          <div className="flex items-center gap-2 mb-2">
            <span className="text-yellow-400 text-xs font-semibold animate-pulse">▶ Şimdi Çalıyor</span>
            <span className="text-gray-500 text-xs">
              {formatDuration(playback.elapsedSeconds)}
            </span>
          </div>
        )}
        <div className="flex items-center gap-2 flex-wrap">
          {playback?.isPlaying ? (
            <button
              onClick={onPause}
              disabled={disabled || !hasVideo}
              className="bg-gray-700 hover:bg-gray-600 disabled:opacity-40 text-white text-xs font-semibold rounded-lg px-3 py-1.5 transition"
            >
              Duraklat
            </button>
          ) : (
            <button
              onClick={onResume}
              disabled={disabled || !hasVideo}
              className="bg-green-700 hover:bg-green-600 disabled:opacity-40 text-white text-xs font-semibold rounded-lg px-3 py-1.5 transition"
            >
              Devam Ettir
            </button>
          )}
          <button
            onClick={onSkip}
            disabled={disabled || !hasVideo}
            className="bg-gray-700 hover:bg-gray-600 disabled:opacity-40 text-white text-xs font-semibold rounded-lg px-3 py-1.5 transition"
          >
            Atla
          </button>
        </div>
      </div>

      {/* Add to Queue */}
      <div className="px-4 py-3 border-b border-gray-800 bg-gray-900">
        <form onSubmit={handleAddUrl} className="flex gap-2">
          <input
            type="url"
            value={addUrl}
            onChange={(e) => setAddUrl(e.target.value)}
            placeholder="YouTube bağlantısı ekle..."
            disabled={disabled}
            className="flex-1 bg-gray-800 border border-gray-700 text-white text-xs rounded-lg px-3 py-2 placeholder-gray-500 focus:outline-none focus:border-violet-500 disabled:opacity-50"
          />
          <button
            type="submit"
            disabled={disabled || !addUrl.trim()}
            className="bg-violet-600 hover:bg-violet-500 disabled:opacity-40 text-white text-xs font-semibold rounded-lg px-3 py-2 transition whitespace-nowrap"
          >
            Şarkı Ekle
          </button>
        </form>
      </div>

      {/* Queue */}
      <div className="flex-1 overflow-y-auto">
        <div className="px-4 py-3">
          <div className="flex items-center justify-between mb-2">
            <p className="text-gray-400 text-xs font-semibold uppercase tracking-wider">
              Sıra ({queue.length})
            </p>
            {queue.length > 0 && (
              <button
                onClick={onClearQueue}
                disabled={disabled}
                className="text-red-400 hover:text-red-300 text-xs transition"
              >
                Temizle
              </button>
            )}
          </div>
          {queue.length === 0 && (
            <p className="text-gray-600 text-xs text-center py-4">Sıra boş</p>
          )}
          {queue.map((item, index) => (
            <div
              key={item.id}
              draggable
              onDragStart={() => handleDragStart(index)}
              onDragOver={(e) => handleDragOver(e, index)}
              onDragEnd={handleDragEnd}
              className={`flex items-center gap-2 rounded-lg px-3 py-2 mb-1 group cursor-grab active:cursor-grabbing transition ${
                dragIndex === index ? "bg-violet-900/40 border border-violet-600/50" : "bg-gray-800/60 hover:bg-gray-800"
              }`}
            >
              <span className="text-gray-600 text-xs w-5 text-center shrink-0">{index + 1}</span>
              <div className="flex-1 min-w-0">
                <p className="text-gray-300 text-xs truncate">{item.title}</p>
                <p className="text-gray-600 text-xs truncate">{item.addedBy}</p>
              </div>
              <button
                onClick={() => onRemoveFromQueue(item.id)}
                className="text-gray-600 hover:text-red-400 opacity-0 group-hover:opacity-100 transition text-xs shrink-0"
              >
                ✕
              </button>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
