// Main chat area with message display and input
import { useEffect, useRef, useState } from "react";
import type { ChatMessage } from "@/types";

interface ChatAreaProps {
  messages: ChatMessage[];
  nickname: string;
  onSend: (text: string) => void;
  disabled?: boolean;
}

function formatTime(ts: number): string {
  const d = new Date(ts);
  return d.toLocaleTimeString("tr-TR", { hour: "2-digit", minute: "2-digit" });
}

function isYouTubeUrl(text: string): boolean {
  return /youtu/.test(text);
}

export function ChatArea({ messages, nickname, onSend, disabled }: ChatAreaProps) {
  const [input, setInput] = useState("");
  const bottomRef = useRef<HTMLDivElement>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  // Auto-scroll to bottom on new messages
  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages]);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const text = input.trim();
    if (!text || disabled) return;
    onSend(text);
    setInput("");
    inputRef.current?.focus();
  };

  return (
    <div className="flex flex-col h-full min-h-0">
      {/* Messages */}
      <div className="flex-1 overflow-y-auto p-4 space-y-2">
        {messages.length === 0 && (
          <div className="flex items-center justify-center h-full">
            <p className="text-gray-600 text-sm">Henüz mesaj yok. İlk mesajı sen gönder!</p>
          </div>
        )}
        {messages.map((msg) => {
          if (msg.type === "system") {
            return (
              <div key={msg.id} className="flex justify-center">
                <span className="text-gray-600 text-xs px-3 py-1 bg-gray-800/50 rounded-full">
                  {msg.text}
                </span>
              </div>
            );
          }

          const isOwn = msg.nickname === nickname;
          const isLink = isYouTubeUrl(msg.text);

          return (
            <div key={msg.id} className={`flex ${isOwn ? "justify-end" : "justify-start"}`}>
              <div className={`max-w-[75%] ${isOwn ? "items-end" : "items-start"} flex flex-col`}>
                {!isOwn && (
                  <span className="text-violet-400 text-xs font-semibold mb-1 px-1">{msg.nickname}</span>
                )}
                <div
                  className={`rounded-2xl px-4 py-2 text-sm break-all ${
                    isOwn
                      ? "bg-violet-600 text-white rounded-br-sm"
                      : "bg-gray-800 text-gray-100 rounded-bl-sm"
                  } ${isLink ? "border border-yellow-500/30" : ""}`}
                >
                  {isLink ? (
                    <div>
                      <span className="text-yellow-400 text-xs block mb-1">🎵 YouTube Bağlantısı</span>
                      <a href={msg.text} target="_blank" rel="noopener noreferrer" className="underline opacity-80 text-xs">
                        {msg.text.length > 50 ? msg.text.slice(0, 50) + "..." : msg.text}
                      </a>
                    </div>
                  ) : (
                    msg.text
                  )}
                </div>
                <span className="text-gray-600 text-xs mt-0.5 px-1">{formatTime(msg.timestamp)}</span>
              </div>
            </div>
          );
        })}
        <div ref={bottomRef} />
      </div>

      {/* Input */}
      <div className="p-3 border-t border-gray-800 bg-gray-900">
        <form onSubmit={handleSubmit} className="flex gap-2">
          <input
            ref={inputRef}
            type="text"
            value={input}
            onChange={(e) => setInput(e.target.value)}
            placeholder={disabled ? "Bir odaya katılın..." : "Mesajınızı yazın..."}
            disabled={disabled}
            className="flex-1 bg-gray-800 border border-gray-700 text-white text-sm rounded-xl px-4 py-2.5 placeholder-gray-500 focus:outline-none focus:border-violet-500 disabled:opacity-50 disabled:cursor-not-allowed transition"
          />
          <button
            type="submit"
            disabled={!input.trim() || disabled}
            className="bg-violet-600 hover:bg-violet-500 disabled:opacity-40 disabled:cursor-not-allowed text-white rounded-xl px-4 py-2.5 transition"
          >
            <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
              <path d="M10.894 2.553a1 1 0 00-1.788 0l-7 14a1 1 0 001.169 1.409l5-1.429A1 1 0 009 15.571V11a1 1 0 112 0v4.571a1 1 0 00.725.962l5 1.428a1 1 0 001.17-1.408l-7-14z" />
            </svg>
          </button>
        </form>
      </div>
    </div>
  );
}
