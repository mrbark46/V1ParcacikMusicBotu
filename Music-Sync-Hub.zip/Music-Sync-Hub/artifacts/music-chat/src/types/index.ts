// Shared types for the music chat platform

export interface RoomUser {
  socketId: string;
  nickname: string;
}

export interface QueueItem {
  id: string;
  url: string;
  title: string;
  addedBy: string;
}

export interface PlaybackState {
  currentVideoId: string | null;
  isPlaying: boolean;
  startedAt: number | null;
  pausedAt: number | null;
  elapsedSeconds: number;
  queue: QueueItem[];
}

export interface ChatMessage {
  id: string;
  nickname: string;
  text: string;
  timestamp: number;
  type: "message" | "system";
}

export interface RoomState {
  id: string;
  name: string;
  users: RoomUser[];
  playback: PlaybackState;
  chatHistory: ChatMessage[];
}

export interface RoomListItem {
  id: string;
  name: string;
  userCount: number;
  hasMusic: boolean;
}
