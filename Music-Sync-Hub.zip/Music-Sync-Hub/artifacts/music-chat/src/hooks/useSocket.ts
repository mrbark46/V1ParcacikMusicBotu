// Custom hook for Socket.IO events and room management
import { useEffect, useRef, useCallback } from "react";
import { getSocket } from "@/lib/socket";
import type { ChatMessage, PlaybackState, QueueItem, RoomListItem, RoomState, RoomUser } from "@/types";

interface UseSocketOptions {
  onRoomList?: (rooms: RoomListItem[]) => void;
  onRoomJoined?: (room: RoomState) => void;
  onUserList?: (users: RoomUser[]) => void;
  onChatMessage?: (msg: ChatMessage) => void;
  onPlaybackUpdate?: (state: PlaybackState) => void;
  onQueueUpdate?: (queue: QueueItem[]) => void;
  onErrorMessage?: (msg: string) => void;
}

export function useSocket(options: UseSocketOptions) {
  const socket = getSocket();
  const optionsRef = useRef(options);
  optionsRef.current = options;

  useEffect(() => {
    const s = socket;

    const onRoomList = (rooms: RoomListItem[]) => optionsRef.current.onRoomList?.(rooms);
    const onRoomJoined = (room: RoomState) => optionsRef.current.onRoomJoined?.(room);
    const onUserList = (users: RoomUser[]) => optionsRef.current.onUserList?.(users);
    const onChatMessage = (msg: ChatMessage) => optionsRef.current.onChatMessage?.(msg);
    const onPlaybackUpdate = (state: PlaybackState) => optionsRef.current.onPlaybackUpdate?.(state);
    const onQueueUpdate = (queue: QueueItem[]) => optionsRef.current.onQueueUpdate?.(queue);
    const onErrorMessage = (msg: string) => optionsRef.current.onErrorMessage?.(msg);

    s.on("room-list", onRoomList);
    s.on("room-joined", onRoomJoined);
    s.on("user-list", onUserList);
    s.on("chat-message", onChatMessage);
    s.on("playback-update", onPlaybackUpdate);
    s.on("queue-update", onQueueUpdate);
    s.on("error-message", onErrorMessage);

    return () => {
      s.off("room-list", onRoomList);
      s.off("room-joined", onRoomJoined);
      s.off("user-list", onUserList);
      s.off("chat-message", onChatMessage);
      s.off("playback-update", onPlaybackUpdate);
      s.off("queue-update", onQueueUpdate);
      s.off("error-message", onErrorMessage);
    };
  }, [socket]);

  const joinRoom = useCallback((roomId: string, roomName: string, nickname: string) => {
    socket.emit("join-room", { roomId, roomName, nickname });
  }, [socket]);

  const sendMessage = useCallback((text: string) => {
    socket.emit("send-message", { text });
  }, [socket]);

  const addToQueue = useCallback((url: string, title: string) => {
    socket.emit("add-to-queue", { url, title });
  }, [socket]);

  const skipSong = useCallback(() => {
    socket.emit("skip-song");
  }, [socket]);

  const pausePlayback = useCallback(() => {
    socket.emit("pause-playback");
  }, [socket]);

  const resumePlayback = useCallback(() => {
    socket.emit("resume-playback");
  }, [socket]);

  const removeFromQueue = useCallback((itemId: string) => {
    socket.emit("remove-from-queue", { itemId });
  }, [socket]);

  const reorderQueue = useCallback((fromIndex: number, toIndex: number) => {
    socket.emit("reorder-queue", { fromIndex, toIndex });
  }, [socket]);

  const clearQueue = useCallback(() => {
    socket.emit("clear-queue");
  }, [socket]);

  const songEnded = useCallback(() => {
    socket.emit("song-ended");
  }, [socket]);

  const requestSync = useCallback(() => {
    socket.emit("request-sync");
  }, [socket]);

  return {
    socket,
    joinRoom,
    sendMessage,
    addToQueue,
    skipSong,
    pausePlayback,
    resumePlayback,
    removeFromQueue,
    reorderQueue,
    clearQueue,
    songEnded,
    requestSync,
  };
}
