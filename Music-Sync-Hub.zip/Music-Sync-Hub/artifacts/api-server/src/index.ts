import { createServer } from "http";
import app from "./app";
import { logger } from "./lib/logger";
import { initSocketIO } from "./lib/socketManager";

const rawPort = process.env["PORT"];

if (!rawPort) {
  throw new Error(
    "PORT environment variable is required but was not provided.",
  );
}

const port = Number(rawPort);

if (Number.isNaN(port) || port <= 0) {
  throw new Error(`Invalid PORT value: "${rawPort}"`);
}

// Create HTTP server from Express app so Socket.IO can share the same port
const httpServer = createServer(app);

// Attach Socket.IO to the HTTP server
initSocketIO(httpServer);

httpServer.listen(port, () => {
  logger.info({ port }, "Server listening with Socket.IO");
});
