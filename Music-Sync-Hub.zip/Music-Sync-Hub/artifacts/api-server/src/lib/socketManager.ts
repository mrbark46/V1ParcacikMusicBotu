// Socket.IO room state manager for multi-room music chat
import { Server as SocketIOServer, Socket } from "socket.io";
import { Server as HttpServer } from "http";
import { logger } from "./logger";

// Represents a user in a room
interface RoomUser {
  socketId: string;
  nickname: string;
  joinedAt: number;
}

// Represents a queue item
interface QueueItem {
  id: string;
  url: string;
  title: string;
  addedBy: string;
}

// Represents the playback state of a room
interface PlaybackState {
  currentVideoId: string | null;
  isPlaying: boolean;
  startedAt: number | null; // server timestamp when playback started
  pausedAt: number | null; // elapsed seconds when paused
  queue: QueueItem[];
}

// Represents a chat message
interface ChatMessage {
  id: string;
  nickname: string;
  text: string;
  timestamp: number;
  type: "message" | "system";
}

// Full room state
interface Room {
  id: string;
  name: string;
  users: Map<string, RoomUser>;
  playback: PlaybackState;
  chatHistory: ChatMessage[];
}

// In-memory store of all rooms
const rooms = new Map<string, Room>();

// Map from socketId to room and nickname
const socketToRoom = new Map<string, { roomId: string; nickname: string }>();

// Generate a YouTube video ID from various URL formats
function extractVideoId(url: string): string | null {
  const patterns = [
    /(?:youtube\.com\/watch\?v=|youtu\.be\/|youtube\.com\/embed\/)([a-zA-Z0-9_-]{11})/,
    /youtube\.com\/shorts\/([a-zA-Z0-9_-]{11})/,
  ];
  for (const pattern of patterns) {
    const match = url.match(pattern);
    if (match) return match[1];
  }
  return null;
}

// Generate unique ID
function generateId(): string {
  return Math.random().toString(36).substring(2, 10) + Date.now().toString(36);
}

// Get current elapsed time for a room's playback
function getElapsedSeconds(room: Room): number {
  const { playback } = room;
  if (!playback.isPlaying || playback.startedAt === null) {
    return playback.pausedAt ?? 0;
  }
  const elapsed = (Date.now() - playback.startedAt) / 1000 + (playback.pausedAt ?? 0);
  return elapsed;
}

// Get or create a room
function getOrCreateRoom(roomId: string, roomName: string): Room {
  if (!rooms.has(roomId)) {
    rooms.set(roomId, {
      id: roomId,
      name: roomName,
      users: new Map(),
      playback: {
        currentVideoId: null,
        isPlaying: false,
        startedAt: null,
        pausedAt: 0,
        queue: [],
      },
      chatHistory: [],
    });
    logger.info({ roomId, roomName }, "Room created");
  }
  return rooms.get(roomId)!;
}

// Serialize room state for client
function serializeRoom(room: Room) {
  return {
    id: room.id,
    name: room.name,
    users: Array.from(room.users.values()).map((u) => ({
      socketId: u.socketId,
      nickname: u.nickname,
    })),
    playback: {
      ...room.playback,
      elapsedSeconds: getElapsedSeconds(room),
    },
    chatHistory: room.chatHistory.slice(-100), // last 100 messages
  };
}

// Get list of all rooms (for sidebar)
function getRoomList() {
  return Array.from(rooms.values()).map((r) => ({
    id: r.id,
    name: r.name,
    userCount: r.users.size,
    hasMusic: r.playback.currentVideoId !== null,
  }));
}

// Advance to next song in queue
function advanceQueue(io: SocketIOServer, room: Room): void {
  if (room.playback.queue.length === 0) {
    room.playback.currentVideoId = null;
    room.playback.isPlaying = false;
    room.playback.startedAt = null;
    room.playback.pausedAt = 0;
  } else {
    const next = room.playback.queue.shift()!;
    const videoId = extractVideoId(next.url);
    room.playback.currentVideoId = videoId;
    room.playback.isPlaying = true;
    room.playback.startedAt = Date.now();
    room.playback.pausedAt = 0;
  }
  io.to(room.id).emit("playback-update", {
    ...room.playback,
    elapsedSeconds: getElapsedSeconds(room),
    queue: room.playback.queue,
  });
}

// Initialize Socket.IO server
export function initSocketIO(httpServer: HttpServer): SocketIOServer {
  const io = new SocketIOServer(httpServer, {
    cors: {
      origin: "*",
      methods: ["GET", "POST"],
    },
    path: "/socket.io",
  });

  io.on("connection", (socket: Socket) => {
    logger.info({ socketId: socket.id }, "Client connected");

    // Send room list on connect
    socket.emit("room-list", getRoomList());

    // Join a room
    socket.on("join-room", ({ roomId, roomName, nickname }: { roomId: string; roomName: string; nickname: string }) => {
      // Leave previous room if any
      const prev = socketToRoom.get(socket.id);
      if (prev) {
        const prevRoom = rooms.get(prev.roomId);
        if (prevRoom) {
          prevRoom.users.delete(socket.id);
          socket.leave(prev.roomId);
          io.to(prev.roomId).emit("user-left", { socketId: socket.id, nickname: prev.nickname });
          io.to(prev.roomId).emit("user-list", Array.from(prevRoom.users.values()));
          // Add system message
          prevRoom.chatHistory.push({
            id: generateId(),
            nickname: "Sistem",
            text: `${prev.nickname} odadan ayrıldı.`,
            timestamp: Date.now(),
            type: "system",
          });
          io.to(prev.roomId).emit("chat-message", prevRoom.chatHistory[prevRoom.chatHistory.length - 1]);
          if (prevRoom.users.size === 0) {
            rooms.delete(prev.roomId);
            logger.info({ roomId: prev.roomId }, "Room deleted (empty)");
          }
        }
      }

      // Join new room
      const room = getOrCreateRoom(roomId, roomName);
      room.users.set(socket.id, { socketId: socket.id, nickname, joinedAt: Date.now() });
      socket.join(roomId);
      socketToRoom.set(socket.id, { roomId, nickname });

      // Add join system message
      const joinMsg: ChatMessage = {
        id: generateId(),
        nickname: "Sistem",
        text: `${nickname} odaya katıldı.`,
        timestamp: Date.now(),
        type: "system",
      };
      room.chatHistory.push(joinMsg);

      // Send full room state to the new user
      socket.emit("room-joined", serializeRoom(room));

      // Broadcast user list update to room
      io.to(roomId).emit("user-list", Array.from(room.users.values()));
      io.to(roomId).emit("chat-message", joinMsg);

      // Update room list for everyone
      io.emit("room-list", getRoomList());

      logger.info({ socketId: socket.id, nickname, roomId }, "User joined room");
    });

    // Send a chat message
    socket.on("send-message", ({ text }: { text: string }) => {
      const info = socketToRoom.get(socket.id);
      if (!info) return;
      const room = rooms.get(info.roomId);
      if (!room) return;

      const msg: ChatMessage = {
        id: generateId(),
        nickname: info.nickname,
        text,
        timestamp: Date.now(),
        type: "message",
      };
      room.chatHistory.push(msg);

      // Check if it's a YouTube URL and add to queue automatically
      const videoId = extractVideoId(text);
      if (videoId) {
        const queueItem: QueueItem = {
          id: generateId(),
          url: text,
          title: `YouTube: ${videoId}`,
          addedBy: info.nickname,
        };
        if (!room.playback.currentVideoId) {
          // Start playing immediately
          room.playback.currentVideoId = videoId;
          room.playback.isPlaying = true;
          room.playback.startedAt = Date.now();
          room.playback.pausedAt = 0;
          io.to(info.roomId).emit("playback-update", {
            ...room.playback,
            elapsedSeconds: 0,
            queue: room.playback.queue,
          });
        } else {
          room.playback.queue.push(queueItem);
          io.to(info.roomId).emit("queue-update", room.playback.queue);
        }
      }

      io.to(info.roomId).emit("chat-message", msg);
    });

    // Add song to queue explicitly
    socket.on("add-to-queue", ({ url, title }: { url: string; title: string }) => {
      const info = socketToRoom.get(socket.id);
      if (!info) return;
      const room = rooms.get(info.roomId);
      if (!room) return;

      const videoId = extractVideoId(url);
      if (!videoId) {
        socket.emit("error-message", "Geçersiz YouTube URL");
        return;
      }

      if (!room.playback.currentVideoId) {
        // Start playing immediately
        room.playback.currentVideoId = videoId;
        room.playback.isPlaying = true;
        room.playback.startedAt = Date.now();
        room.playback.pausedAt = 0;
        io.to(info.roomId).emit("playback-update", {
          ...room.playback,
          elapsedSeconds: 0,
          queue: room.playback.queue,
        });
      } else {
        const queueItem: QueueItem = {
          id: generateId(),
          url,
          title: title || `YouTube: ${videoId}`,
          addedBy: info.nickname,
        };
        room.playback.queue.push(queueItem);
        io.to(info.roomId).emit("queue-update", room.playback.queue);
      }

      // System message for queue add
      const sysMsg: ChatMessage = {
        id: generateId(),
        nickname: "Sistem",
        text: `${info.nickname} sıraya şarkı ekledi.`,
        timestamp: Date.now(),
        type: "system",
      };
      room.chatHistory.push(sysMsg);
      io.to(info.roomId).emit("chat-message", sysMsg);
    });

    // Skip current song
    socket.on("skip-song", () => {
      const info = socketToRoom.get(socket.id);
      if (!info) return;
      const room = rooms.get(info.roomId);
      if (!room) return;

      advanceQueue(io, room);

      const sysMsg: ChatMessage = {
        id: generateId(),
        nickname: "Sistem",
        text: `${info.nickname} şarkıyı atladı.`,
        timestamp: Date.now(),
        type: "system",
      };
      room.chatHistory.push(sysMsg);
      io.to(info.roomId).emit("chat-message", sysMsg);
    });

    // Pause playback
    socket.on("pause-playback", () => {
      const info = socketToRoom.get(socket.id);
      if (!info) return;
      const room = rooms.get(info.roomId);
      if (!room || !room.playback.isPlaying) return;

      const elapsed = getElapsedSeconds(room);
      room.playback.isPlaying = false;
      room.playback.pausedAt = elapsed;
      room.playback.startedAt = null;

      io.to(info.roomId).emit("playback-update", {
        ...room.playback,
        elapsedSeconds: elapsed,
        queue: room.playback.queue,
      });
    });

    // Resume playback
    socket.on("resume-playback", () => {
      const info = socketToRoom.get(socket.id);
      if (!info) return;
      const room = rooms.get(info.roomId);
      if (!room || room.playback.isPlaying || !room.playback.currentVideoId) return;

      room.playback.isPlaying = true;
      room.playback.startedAt = Date.now();
      // pausedAt carries over as the offset

      io.to(info.roomId).emit("playback-update", {
        ...room.playback,
        elapsedSeconds: room.playback.pausedAt ?? 0,
        queue: room.playback.queue,
      });
    });

    // Remove from queue
    socket.on("remove-from-queue", ({ itemId }: { itemId: string }) => {
      const info = socketToRoom.get(socket.id);
      if (!info) return;
      const room = rooms.get(info.roomId);
      if (!room) return;

      room.playback.queue = room.playback.queue.filter((item) => item.id !== itemId);
      io.to(info.roomId).emit("queue-update", room.playback.queue);
    });

    // Reorder queue
    socket.on("reorder-queue", ({ fromIndex, toIndex }: { fromIndex: number; toIndex: number }) => {
      const info = socketToRoom.get(socket.id);
      if (!info) return;
      const room = rooms.get(info.roomId);
      if (!room) return;

      const queue = [...room.playback.queue];
      if (fromIndex < 0 || fromIndex >= queue.length || toIndex < 0 || toIndex >= queue.length) return;
      const [moved] = queue.splice(fromIndex, 1);
      queue.splice(toIndex, 0, moved);
      room.playback.queue = queue;
      io.to(info.roomId).emit("queue-update", room.playback.queue);
    });

    // Clear queue
    socket.on("clear-queue", () => {
      const info = socketToRoom.get(socket.id);
      if (!info) return;
      const room = rooms.get(info.roomId);
      if (!room) return;

      room.playback.queue = [];
      io.to(info.roomId).emit("queue-update", room.playback.queue);
    });

    // Song ended — advance to next
    socket.on("song-ended", () => {
      const info = socketToRoom.get(socket.id);
      if (!info) return;
      const room = rooms.get(info.roomId);
      if (!room) return;

      // Only advance if this user is telling us the song ended (prevent duplicates)
      // Simple approach: first one to report wins
      if (room.playback.currentVideoId) {
        advanceQueue(io, room);
      }
    });

    // Request sync (for late joiners or page refresh)
    socket.on("request-sync", () => {
      const info = socketToRoom.get(socket.id);
      if (!info) return;
      const room = rooms.get(info.roomId);
      if (!room) return;

      socket.emit("playback-update", {
        ...room.playback,
        elapsedSeconds: getElapsedSeconds(room),
        queue: room.playback.queue,
      });
    });

    // Handle disconnect
    socket.on("disconnect", () => {
      const info = socketToRoom.get(socket.id);
      if (info) {
        const room = rooms.get(info.roomId);
        if (room) {
          room.users.delete(socket.id);
          io.to(info.roomId).emit("user-list", Array.from(room.users.values()));

          const leaveMsg: ChatMessage = {
            id: generateId(),
            nickname: "Sistem",
            text: `${info.nickname} odadan ayrıldı.`,
            timestamp: Date.now(),
            type: "system",
          };
          room.chatHistory.push(leaveMsg);
          io.to(info.roomId).emit("chat-message", leaveMsg);

          if (room.users.size === 0) {
            rooms.delete(info.roomId);
            logger.info({ roomId: info.roomId }, "Room deleted (empty)");
          }

          io.emit("room-list", getRoomList());
        }
        socketToRoom.delete(socket.id);
      }
      logger.info({ socketId: socket.id }, "Client disconnected");
    });
  });

  return io;
}
